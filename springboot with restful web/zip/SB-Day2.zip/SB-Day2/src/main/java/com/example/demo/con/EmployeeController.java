package com.example.demo.con;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.tech.demo.dto.Employee;

@RestController
public class EmployeeController {

	
	public EmployeeController() {
	System.out.println("inside EmployeeController const");
	}
	
	//@PostMapping("/createEmp")
	@RequestMapping(value="/createEmp", method = RequestMethod.POST)
	public Employee creteEmployee(@RequestBody Employee emp)
	{
		System.out.println("inside creteEmployee " +emp);
		return emp;
	}
	//@PutMapping("/updateEmp")
	@RequestMapping(value="/updateEmp", method = RequestMethod.PUT)
	public Employee updateEmployee(@RequestBody Employee emp)
	{
		System.out.println("inside updateEmployee " +emp);
		return emp;
	}
	
	//@DeleteMapping("/deleteEmp/{id}")
	@RequestMapping(value="/deleteEmp/{id}", method = RequestMethod.DELETE)
	public String deleteEmployee(@PathVariable("id") int id1)
	{
		System.out.println("inside deleteEmployee " +id1);
		return "delete successfuly for id "+id1;
	}
	
}
